# Yuva Intern - Week 2: Supervised Machine Learning

## Project overview
This project trains and compares:
- Regression: Linear Regression and Random Forest Regressor on the Scikit-learn Diabetes dataset.
- Classification: Logistic Regression and Decision Tree Classifier on the Scikit-learn Breast Cancer Wisconsin dataset.

## Requirements
Python 3.9 or later

Install dependencies:
```bash
pip install numpy scikit-learn
```

## Run
```bash
python week2_supervised_ml.py
```

The script prints MAE, RMSE and R-squared for regression, and accuracy, precision, recall, F1-score and confusion matrices for classification.

## Files
- `week2_supervised_ml.py` - complete source code
- `Yuva_Intern_Week_2_Report.docx` - project report

## Dataset note
Both datasets are built into Scikit-learn and are loaded automatically. The breast-cancer dataset is used only as an educational benchmark, not for medical diagnosis.
